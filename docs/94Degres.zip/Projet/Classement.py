import pygame
import random
import math
import time
from pygame.locals import*
import linecache
def classement():
    pygame.init()
    fenetre = pygame.display.set_mode((650, 500))
    fichier = open('classement.txt', 'r')

    xfirst=30
    yfirst=170
    xsecond=30
    ysecond=240
    xthird=30
    ythird=310
    xfourth=30
    yfourth=390
    xfifth=30
    yfifth=450

    NumberOfLine = 0
    for line in fichier:
        NumberOfLine += 1
    first = linecache.getline('classement.txt', 1).strip()
    second = linecache.getline('classement.txt', 2).strip()
    third = linecache.getline('classement.txt', 3).strip()
    fourth = linecache.getline('classement.txt', 4).strip()
    fifth = linecache.getline('classement.txt', 5).strip()
    font = pygame.font.SysFont("broadway", 40, bold=False, italic=False)
    textfirst = font.render(str(first), 1, (255, 255, 255))
    textsecond = font.render(str(second), 1, (255, 255, 255))
    textthird = font.render(str(third), 1, (255, 255, 255))
    textfourth = font.render(str(fourth), 1, (255, 255, 255))
    textfifth = font.render(str(fifth), 1, (255, 255, 255))
    pygame.display.flip()
    intro=True
    pygame.display.set_caption('Classement des joueurs')
    for i in range(1, 255,5):
        podium = pygame.image.load("podium.png")
        fenetre.fill((0,0,0))
        podium.fill((i, i, i, i), special_flags=BLEND_RGBA_MULT)
        fenetre.blit(podium, (0,0))
        pygame.display.flip()
        time.sleep(0.0001)
    intro = False
    boucle=True
    while boucle==True:
        for event in pygame.event.get():
            fenetre.blit(textfirst, (xfirst, yfirst))
            fenetre.blit(textsecond, (xsecond, ysecond))
            fenetre.blit(textthird, (xthird, ythird))
            fenetre.blit(textfourth, (xfourth, yfourth))
            fenetre.blit(textfifth, (xfifth, yfifth))
            pygame.display.flip()

            if event.type == KEYUP and event.key == K_ESCAPE:
                boucle = False
            elif event.type == QUIT:
                boucle=False
        pygame.display.flip()
    classement=False
    pygame.display.flip()
    return classement