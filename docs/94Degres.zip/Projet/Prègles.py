import pygame, random, math
from pygame.locals import*
def Pregles():
    fenetre = pygame.display.set_mode((1000, 600))
    pygame.display.set_caption('Prêt ?')
    fenetre.fill((57, 234, 250))
    regle=pygame.image.load("Pregle.png")
    fenetre.blit(regle,(0,0))
    pygame.display.flip()
    continuer = True
    while continuer == True:
        for event in pygame.event.get():
             if event.type == KEYUP and event.key == K_ESCAPE:
                continuer=False
             if event.type == KEYUP and event.key == K_RETURN:
                continuer=False
             if event.type == QUIT:
                continuer = False