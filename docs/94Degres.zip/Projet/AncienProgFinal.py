import pygame
import random
import math
import time
from pygame.locals import*
from jeu_france import*
from regles import*
from random import uniform
from bonneteau import*
from monde import*
menu=True
while menu==True:
    retour=False
    pygame.init()
    fenetre = pygame.display.set_mode((1000, 600))
    fenetre.fill((253, 17, 251))

    choix4=pygame.image.load("choix4.png")
    fenetre.blit(choix4,(210,150))

    choix5=pygame.image.load("choix5.png")
    fenetre.blit(choix5,(210,350))


    pygame.display.flip()
    boucle1 = True
    while boucle1 == True:

        fenetre.blit(choix4,(210,150))
        fenetre.blit(choix5,(210,350))
        for event in pygame.event.get():

            if event.type==MOUSEMOTION and event.pos[0]<810 and event.pos[0]>210 and event.pos[1]>150 and event.pos[1]<250:
                select4=pygame.image.load("select4.png")
                fenetre.blit(select4,(210,150))

            elif event.type==MOUSEMOTION and event.pos[0]<810 and event.pos[0]>210 and event.pos[1]>350 and event.pos[1]<450:
                select5=pygame.image.load("select5.png")
                fenetre.blit(select5,(210,350))

            if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<810 and event.pos[0]>210 and event.pos[1]>150 and event.pos[1]<250:
                    bonneteau()
                    boucle1=False

            if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<810 and event.pos[1]>350 and event.pos[1]<450:
                boucle1=False
                retour=True

            if boucle1==True:
                pygame.display.flip()
            if event.type == QUIT:
                    boucle1 = False
                    menu=False
            elif event.type == KEYUP and event.key == K_ESCAPE:
                    boucle1 = False
                    menu=False
    pygame.quit()


    while retour==True:
        pygame.init()
        fenetre = pygame.display.set_mode((1000, 600))
        fenetre.fill((42, 89, 176))

        choix1=pygame.image.load("choix1.png")
        fenetre.blit(choix1,(210,70))

        choix2=pygame.image.load("choix2.png")
        fenetre.blit(choix2,(210,270))

        choix3=pygame.image.load("choix3.png")
        fenetre.blit(choix3,(210,470))

        retour=pygame.image.load("retour.png")
        fenetre.blit(retour,(0,0))

        pygame.display.flip()
        boucle2 = True
        while boucle2 == True:

            fenetre.blit(choix1,(210,70))
            fenetre.blit(choix2,(210,270))
            fenetre.blit(choix3,(210,470))
            for event in pygame.event.get():

                if event.type==MOUSEMOTION and event.pos[0]<810 and event.pos[0]>210 and event.pos[1]>70 and event.pos[1]<170:
                    select1=pygame.image.load("select1.png")
                    fenetre.blit(select1,(210,70))

                elif event.type==MOUSEMOTION and event.pos[0]<810 and event.pos[0]>210 and event.pos[1]>270 and event.pos[1]<370:
                    select2=pygame.image.load("select2.png")
                    fenetre.blit(select2,(210,270))
                elif event.type==MOUSEMOTION and event.pos[0]<810 and event.pos[0]>210 and event.pos[1]>470 and event.pos[1]<570:
                    select3=pygame.image.load("select3.png")
                    fenetre.blit(select3,(210,470))

                if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<810 and event.pos[0]>210 and event.pos[1]>70 and event.pos[1]<170:
                        jeu_france()
                        boucle2=False
                        retour=True
                if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<810 and event.pos[1]>270 and event.pos[1]<370:
                        monde()
                        boucle2=False
                        retour=True
                if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<810 and event.pos[1]>470 and event.pos[1]<570:
                        regles()
                        boucle2=False
                        retour=True

                if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<100 and event.pos[1]<100:
                    boucle2=False
                    retour=False

                if boucle2==True:
                    pygame.display.flip()

                if event.type == QUIT:
                        boucle2 = False
                elif event.type == KEYUP and event.key == K_ESCAPE:
                        boucle2 = False
        pygame.quit()