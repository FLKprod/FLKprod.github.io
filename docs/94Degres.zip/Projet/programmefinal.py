﻿from jeu_france import*
from jeu_europe import*
from PaysEurope import*
from PaysMonde import*
from Prègles import*
from Music import*
from regles import*
from jeu_monde import*
from Classement import*
intro=True
r=g=b=i=0
menu=True
while menu==True:
    #Initialisation des variables
    xtexte=254
    ytexte=200
    xtexteII=266
    ytexteII=350
    retour=False
    music=False
    podium=False
    jeufinal=False
    #creation de la fenetre et chargement des textures
    fenetre = pygame.display.set_mode((1000, 600))
    pygame.display.set_caption('Menu Principal')

    #fondu au demarrage du jeu

    if intro==True:
        for i in range(1, 255, 2):
            r = abs(69 / 255 * i)
            g = abs(93 / 255 * i)
            b = abs(215/255*i)
            fenetre.fill((r, g, b))
            Principal = pygame.image.load("CityQuizz.png")
            PrincipalII = pygame.image.load("son.png")
            Principal.fill((i, i, i ,i), special_flags=BLEND_RGBA_MULT)
            PrincipalII.fill((i, i, i, i), special_flags=BLEND_RGBA_MULT)
            fenetre.blit(Principal, (xtexte, ytexte))
            fenetre.blit(PrincipalII, (0, 0))
            pygame.display.flip()
            time.sleep(0.001)
        intro=False
    fenetre.fill((69, 93, 215))
    pygame.display.flip()
    boucle1 = True
    while boucle1 == True:
        fenetre.blit(Principal,(xtexte,ytexte))
        fenetre.blit(PrincipalII, (0, 0))
        for event in pygame.event.get():
            if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<xtexte+492 and event.pos[1]>ytexte and event.pos[1]<ytexte+100:
                boucle1=False
                retour=True
            elif event.type==MOUSEMOTION and event.pos[0]<xtexte+492 and event.pos[0]>xtexte and event.pos[1]>ytexte and event.pos[1]<ytexte+100:
                Principalselect=pygame.image.load("CityQuizzII.png")
                fenetre.blit(Principalselect,(xtexte,ytexte))
            elif event.type==MOUSEMOTION and event.pos[0]<100 and event.pos[0]>0 and event.pos[1]>0 and event.pos[1]<100:
                sonselect = pygame.image.load("sonselect.png")
                fenetre.blit(sonselect, (0,0))
            elif event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<1000 and event.pos[0]>900and event.pos[1]>0 and event.pos[1]<100:
                podium=True
                boucle1 = False
            elif event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<100 and event.pos[0]>0and event.pos[1]>0 and event.pos[1]<100:
                music=True
                boucle1 = False
            elif event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<1000 and event.pos[0]>900and event.pos[1]>500 and event.pos[1]<600:
                jeufinal=True
                boucle1 = False
            if boucle1==True:
                pygame.display.flip()
            if event.type == QUIT:
                    boucle1 = False
                    menu=False
            elif event.type == KEYUP and event.key == K_ESCAPE:
                    boucle1 = False
                    menu=False
    pygame.display.flip()
    while podium==True:
        classement()
        podium = False
        boucle1 = True
    while music==True:
        Music()
        music = False
        boucle1 = True
    while retour==True:
        pygame.init()
        fenetre = pygame.display.set_mode((1000, 600))
        pygame.display.set_caption('Entrainez vous !')
        fenetre.fill((42, 89, 176))
        choix1=pygame.image.load("jeufrance.png")
        fenetre.blit(choix1,(210,70))
        choix2=pygame.image.load("jeueurope.png")
        fenetre.blit(choix2,(210,270))
        choix3=pygame.image.load("jeumonde.png")
        fenetre.blit(choix3,(210,470))
        retour=pygame.image.load("retour.png")
        fenetre.blit(retour,(0,0))
        select1 = pygame.image.load("jeufranceII.png")
        select2 = pygame.image.load("jeueuropeII.png")
        select3=pygame.image.load("jeumondeII.png")
        pygame.display.flip()
        boucle2 = True
        while boucle2 == True:
            fenetre.blit(choix1,(210,70))
            fenetre.blit(choix2,(210,270))
            fenetre.blit(choix3,(210,470))
            fenetre.blit(choix2, (610, 270))
            fenetre.blit(choix3, (610, 470))
            for event in pygame.event.get():
                if event.type==MOUSEMOTION and event.pos[0]<420 and event.pos[0]>210 and event.pos[1]>70 and event.pos[1]<170:
                    fenetre.blit(select1,(210,70))
                elif event.type==MOUSEMOTION and event.pos[0]<420 and event.pos[0]>210 and event.pos[1]>270 and event.pos[1]<370:
                    fenetre.blit(select2,(210,270))
                elif event.type==MOUSEMOTION and event.pos[0]<420 and event.pos[0]>210 and event.pos[1]>470 and event.pos[1]<570:
                    fenetre.blit(select3,(210,470))
                elif event.type==MOUSEMOTION and event.pos[0]<820 and event.pos[0]>610 and event.pos[1]>270 and event.pos[1]<340:
                    fenetre.blit(select2,(610,270))
                elif event.type==MOUSEMOTION and event.pos[0]<820 and event.pos[0]>610 and event.pos[1]>470 and event.pos[1]<540:
                    fenetre.blit(select3,(610,470))
                if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<420 and event.pos[0]>210 and event.pos[1]>70 and event.pos[1]<170:
                        regles()
                        jeu_france()
                        boucle2=False
                        retour=True
                if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<420 and event.pos[1]>270 and event.pos[1]<370:
                        regles()
                        jeu_europe()
                        boucle2=False
                        retour=True
                if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<420 and event.pos[1]>470 and event.pos[1]<570:
                        regles()
                        jeu_monde()
                        boucle2=False
                        retour=True
                if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<820 and event.pos[0]>610 and event.pos[1]>270 and event.pos[1]<340:
                        Pregles()
                        jeu_pays_europe()
                        boucle2=False
                        retour=True
                if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<820 and event.pos[0]>610 and event.pos[1]>470 and event.pos[1]<540:
                        Pregles()
                        jeu_pays_monde()
                        boucle2=False
                        retour=True
                if event.type==MOUSEBUTTONDOWN and event.button==1 and event.pos[0]<100 and event.pos[1]<100:
                    boucle2=False
                    retour=False
                if boucle2==True:
                    pygame.display.flip()
                if event.type == QUIT:
                    boucle2 = False
                    retour = False
                elif event.type == KEYUP and event.key == K_ESCAPE:
                    boucle2 = False
                    retour = False
pygame.quit()